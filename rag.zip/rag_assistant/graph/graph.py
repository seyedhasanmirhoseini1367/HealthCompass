# rag_assistant/graph/graph.py
"""
LangGraph StateGraph for HealthCompass RAG.

Flow:
    router_node
        ├── trajectory  → trajectory_node   [PhD proposal Gap 1]
        ├── lab_results → lab_results_node
        ├── medications → medications_node
        ├── wearable    → wearable_node
        ├── diagnosis   → diagnosis_node
        ├── records     → records_node
        └── general     → general_node
                              ↓
                        generate_node
                              ↓
                        verify_node
                    needs_retry=True  → back to records_node (broader retry)
                    needs_retry=False → END

Trajectory mode:
    When router_node detects a temporal query, it routes to trajectory_node
    which builds a chronologically ordered context string instead of
    similarity-ranked chunks.  generate_node then uses that context with
    the trajectory-specific system prompt so the LLM reasons about trends.
"""
import logging

from langgraph.graph import StateGraph, END

from .state import HealthState
from .nodes import (
    router_node,
    trajectory_node,
    lab_results_node, medications_node, wearable_node,
    diagnosis_node, records_node, general_node,
    generate_node, verify_node,
)

logger = logging.getLogger(__name__)

ROUTE_TO_NODE = {
    'trajectory':  'trajectory_node',
    'lab_results': 'lab_results_node',
    'medications': 'medications_node',
    'wearable':    'wearable_node',
    'diagnosis':   'diagnosis_node',
    'records':     'records_node',
    'general':     'general_node',
}


def _route_from_router(state: HealthState) -> str:
    return ROUTE_TO_NODE.get(state.get('route', 'general'), 'general_node')


def _route_from_verify(state: HealthState) -> str:
    if state.get('needs_retry', False):
        # Always retry via records_node (all-types, broader top_k) regardless
        # of the original route — this gives the best chance of finding context.
        logger.debug('verify → retry via records_node')
        return 'records_node'
    return END


def build_graph() -> StateGraph:
    graph = StateGraph(HealthState)

    # ── Nodes ──────────────────────────────────────────────────────────────────
    graph.add_node('router_node',       router_node)
    graph.add_node('trajectory_node',   trajectory_node)
    graph.add_node('lab_results_node',  lab_results_node)
    graph.add_node('medications_node',  medications_node)
    graph.add_node('wearable_node',     wearable_node)
    graph.add_node('diagnosis_node',    diagnosis_node)
    graph.add_node('records_node',      records_node)
    graph.add_node('general_node',      general_node)
    graph.add_node('generate_node',     generate_node)
    graph.add_node('verify_node',       verify_node)

    # ── Entry ──────────────────────────────────────────────────────────────────
    graph.set_entry_point('router_node')

    # ── router → search node (conditional on detected route) ──────────────────
    graph.add_conditional_edges(
        'router_node',
        _route_from_router,
        {v: v for v in ROUTE_TO_NODE.values()},
    )

    # ── All search/trajectory nodes → generate ─────────────────────────────────
    for node in ROUTE_TO_NODE.values():
        graph.add_edge(node, 'generate_node')

    # ── generate → verify ──────────────────────────────────────────────────────
    graph.add_edge('generate_node', 'verify_node')

    # ── verify → retry (always via records_node) or END ───────────────────────
    graph.add_conditional_edges(
        'verify_node',
        _route_from_verify,
        {'records_node': 'records_node', END: END},
    )

    return graph


# Compiled graph — imported by rag_service.py
health_graph = build_graph().compile()
