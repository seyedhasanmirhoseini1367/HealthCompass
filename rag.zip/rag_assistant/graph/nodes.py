# rag_assistant/graph/nodes.py
"""
LangGraph nodes for the HealthCompass RAG pipeline.

router_node      — keyword-based routing (no LLM call).
                   Checks for TEMPORAL intent FIRST; if detected, routes to
                   trajectory_node so the LLM receives a chronologically
                   ordered context rather than a similarity-ranked one.
                   For non-temporal queries: detects ALL matching domain
                   routes; if 2+ match, falls back to all-types retrieval.

trajectory_node  — NEW (PhD proposal Gap 1).
                   Calls TrajectoryService to build an ordered biomarker
                   trajectory and stores it in state['trajectory_context'].
                   Also stores source chunks in state['context_chunks'] so
                   the sources panel in the UI works unchanged.

*_node           — retrieval scoped to a medical domain
generate_node    — LLM generation (Gemini → Anthropic → OpenAI).
                   Checks state['trajectory_context']; if present, passes it
                   as a context override with the trajectory system prompt.
verify_node      — retries ONLY when no chunks were retrieved (max 2×).
"""
import logging
from typing import Any, Dict, List, Optional

from .state import HealthState

logger = logging.getLogger(__name__)


# ── Route keyword maps ─────────────────────────────────────────────────────────

_ROUTE_KEYWORDS: Dict[str, List[str]] = {
    'lab_results': [
        'lab', 'blood', 'test', 'result', 'cholesterol', 'glucose', 'hba1c',
        'haemoglobin', 'hemoglobin', 'creatinine', 'thyroid', 'tsh', 'wbc',
        'rbc', 'platelet', 'urine', 'bilirubin', 'ferritin', 'vitamin',
        'abnormal', 'reference range', 'measurement', 'level', 'sugar level',
        'iron', 'calcium', 'sodium', 'potassium', 'ldl', 'hdl', 'triglyceride',
        'egfr', 'gfr', 'kidney function',
    ],
    'medications': [
        'medication', 'medicine', 'drug', 'prescription', 'dose', 'dosage',
        'tablet', 'capsule', 'pill', 'mg', 'ml', 'side effect', 'interaction',
        'antibiotic', 'painkiller', 'insulin', 'statin', 'aspirin',
        'pharmacy', 'refill', 'treatment', 'taking', 'prescribed',
        'metformin', 'lisinopril', 'atorvastatin', 'omeprazole',
    ],
    'wearable': [
        'heart rate', 'steps', 'sleep', 'activity', 'calories', 'exercise',
        'workout', 'bpm', 'pulse', 'oxygen', 'spo2', 'fitbit', 'garmin',
        'oura', 'apple watch', 'wearable', 'sensor', 'tracker', 'distance',
        'resting', 'stress', 'hrv', 'heart rate variability', 'active minutes',
    ],
    'diagnosis': [
        'diagnosis', 'condition', 'disease', 'symptom', 'imaging', 'mri',
        'ct scan', 'x-ray', 'xray', 'ultrasound', 'ecg', 'eeg', 'scan',
        'report', 'radiology', 'discharge', 'hospital', 'surgery', 'procedure',
        'finding', 'impression', 'clinical note', 'assessment',
    ],
    'records': [
        'record', 'history', 'summary', 'timeline', 'overview', 'all',
        'previous', 'past', 'when', 'how long', 'last time', 'show me',
        'list', 'everything',
    ],
}

# Temporal intent keywords (must match TrajectoryService._TEMPORAL_KEYWORDS
# for consistent routing — a subset is enough here to trigger the route).
_TEMPORAL_ROUTE_KEYWORDS = [
    'getting better', 'getting worse', 'is it getting',
    'over time', 'over the past', 'over the last',
    'trend', 'trending', 'trajectory', 'progression', 'progress',
    'improving', 'worsening', 'deteriorating', 'declining',
    'going up', 'going down', 'increasing', 'decreasing',
    'changed', 'change over', 'compared to last', 'since last',
    'month by month', 'each visit', 'fluctuating', 'stable over',
    'last 6 months', 'last 3 months', 'last year', 'last month',
    'should i be worried', 'is this getting', 'history of my',
]


def _is_temporal(question: str) -> bool:
    q = question.lower()
    return any(kw in q for kw in _TEMPORAL_ROUTE_KEYWORDS)


def _detect_route(question: str) -> str:
    """
    Returns the single best route for a question.

    Temporal queries take priority → 'trajectory'.
    Multi-domain matches → 'records' (all-types retrieval).
    Single match → that domain.
    No match → 'general'.
    """
    from django.conf import settings
    if settings.RAG_CONFIG.get('TRAJECTORY_ENABLED', True) and _is_temporal(question):
        logger.debug('RAG router: temporal query detected → trajectory')
        return 'trajectory'

    q = question.lower()
    matched = [
        route for route, keywords in _ROUTE_KEYWORDS.items()
        if any(kw in q for kw in keywords)
    ]

    if len(matched) == 0:
        return 'general'
    if len(matched) == 1:
        return matched[0]
    logger.debug('Multi-route detected %s → falling back to records', matched)
    return 'records'


# ── Router ────────────────────────────────────────────────────────────────────

def router_node(state: HealthState) -> Dict[str, Any]:
    route = _detect_route(state['question'])
    logger.debug('RAG router: "%s" → %s', state['question'][:60], route)
    return {'route': route, 'trajectory_context': ''}


# ── Trajectory node (PhD proposal Gap 1) ─────────────────────────────────────

def trajectory_node(state: HealthState) -> Dict[str, Any]:
    """
    Build a chronological biomarker trajectory for the patient's query.

    1. Calls TrajectoryService.get_trajectory_context()
    2. Stores the formatted trajectory in state['trajectory_context']
    3. Stores source_chunks in state['context_chunks'] for the sources panel

    If no trajectory data is found (patient has no matching records), the
    context_chunks will be empty; verify_node will trigger a retry via the
    records_node so the query still gets an answer.
    """
    try:
        from django.contrib.auth import get_user_model
        from rag_assistant.services.trajectory_service import TrajectoryService

        User    = get_user_model()
        patient = User.objects.get(pk=state['patient_id'])
        svc     = TrajectoryService()
        context, source_chunks = svc.get_trajectory_context(patient, state['question'])

        if context:
            logger.info(
                'trajectory_node: built trajectory (%d chars, %d source chunks)',
                len(context), len(source_chunks),
            )
        else:
            logger.info('trajectory_node: no trajectory data found for this query')

        return {
            'trajectory_context': context,
            'context_chunks':     source_chunks,
        }
    except Exception as exc:
        logger.exception('trajectory_node failed: %s', exc)
        return {'trajectory_context': '', 'context_chunks': []}


# ── Retrieval helpers ─────────────────────────────────────────────────────────

def _retrieve(
    state:         HealthState,
    document_type: Optional[str] = None,
    top_k:         Optional[int] = None,
    query_intent:  Optional[str] = None,
) -> Dict[str, Any]:
    try:
        from django.contrib.auth import get_user_model
        from rag_assistant.services.retrieval_service import RetrievalService

        User    = get_user_model()
        patient = User.objects.get(pk=state['patient_id'])
        svc     = RetrievalService()
        chunks  = svc.retrieve(
            patient       = patient,
            query         = state['question'],
            document_type = document_type,
            top_k         = top_k,
            query_intent  = query_intent,
        )
        return {'context_chunks': chunks, 'trajectory_context': ''}
    except Exception as exc:
        logger.exception('Retrieval failed: %s', exc)
        return {'context_chunks': [], 'trajectory_context': ''}


# ── Search nodes ───────────────────────────────────────────────────────────────

def lab_results_node(state: HealthState) -> Dict[str, Any]:
    return _retrieve(state, 'lab_result', query_intent='lab_results')

def medications_node(state: HealthState) -> Dict[str, Any]:
    return _retrieve(state, 'medication', query_intent='medication')

def wearable_node(state: HealthState) -> Dict[str, Any]:
    return _retrieve(state, 'wearable', query_intent='general')

def diagnosis_node(state: HealthState) -> Dict[str, Any]:
    return _retrieve(state, None, query_intent='diagnostic')

def records_node(state: HealthState) -> Dict[str, Any]:
    return _retrieve(state, None, top_k=10, query_intent='general')

def general_node(state: HealthState) -> Dict[str, Any]:
    return _retrieve(state, None, query_intent='general')


# ── Generate ──────────────────────────────────────────────────────────────────

def generate_node(state: HealthState) -> Dict[str, Any]:
    """
    Call the LLM.  If a trajectory context was built, pass it as a context
    override with the dedicated trajectory system prompt so the LLM knows it
    is reasoning about temporal change, not answering a static factual query.
    """
    try:
        from rag_assistant.services.generation_service import generate
        trajectory_context = state.get('trajectory_context', '')
        answer, _, provider = generate(
            chunks             = state.get('context_chunks', []),
            query              = state['question'],
            history            = state.get('history', []),
            context_override   = trajectory_context,
        )
        return {'answer': answer, 'llm_provider': provider}
    except Exception as exc:
        logger.exception('Generation failed: %s', exc)
        return {
            'answer':       'I was unable to generate a response. Please try again.',
            'llm_provider': 'error',
        }


# ── Verify ────────────────────────────────────────────────────────────────────

def verify_node(state: HealthState) -> Dict[str, Any]:
    """
    Decides whether to retry retrieval + generation.

    Retries when no context chunks were retrieved AND the retry limit is not
    reached.  This also fires when trajectory_node found no data (empty
    context_chunks + empty trajectory_context), so the query gets a second
    attempt via standard retrieval.
    """
    retry_count = state.get('retry_count', 0)
    no_chunks   = len(state.get('context_chunks', [])) == 0

    needs_retry = no_chunks and retry_count < 2

    if needs_retry:
        logger.debug(
            'verify → retry (no chunks, attempt %d)', retry_count + 1
        )

    return {
        'needs_retry':    needs_retry,
        'retry_count':    retry_count + 1,
        # Clear trajectory context on retry so records_node is used normally
        'trajectory_context': '' if needs_retry else state.get('trajectory_context', ''),
    }
